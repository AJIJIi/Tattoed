import PlaygroundSupport

PlaygroundPage.current.setLiveView(Cover())
