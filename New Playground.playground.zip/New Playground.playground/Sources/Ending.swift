import SwiftUI

public struct Ending: View {
    public init() {}
    
    @State private var selection: String?
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: SixthPage(), tag: "SixthPage", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "ending.jpeg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 622)
                        .padding(.bottom, 5)
                }
                
                HStack {
                    Button(action: {
                        self.selection = "SixthPage"
                    }) {
                        if let image = UIImage(named: "arrowLeft.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.leading, 10)
                    .frame(width: 58.4, height: 30)
                    
                    Spacer()
                }
                .padding(.bottom, 10)
                
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
