import SwiftUI

public struct SecondPage: View {
    public init() {
        self.label = Text(text)
        self.words = text.components(separatedBy: " ")
    }
    
    @State private var selection: String?
    @State private var currentWord: Int?
    @State private var currentChar: Int?
    @State private var startTime: Date?
    @State private var label = Text("")
    private var words: [String] = []
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    private let text = "The fair is coming up. A cute pumpkin that isn't scary wants to win the parade and prove that pumpkins don't have to be scary and can be friendly to people. The sweet little pumpkin also wants to prove that pumpkins can be cute and smiley, not only sad and scary. \nNobody believes in her. The pumpkin’s friends mock and tease her a lot. The lil' cute pumpkin wants to show everyone that they are wrong but doesn’t know how to prove it."
    private let timeCodes = [0.0, 0.4, 0.8, 0.9, 1.1, 1.8, 2.2, 2.5, 2.9, 3.3, 3.8, 4.5, 4.9, 5.1, 5.6, 5.9, 6.3, 6.6, 7.1, 7.4, 7.9, 8.2, 8.4, 8.7, 9.1, 9.5, 9.8, 10.2, 10.4, 11.1, 11.3, 11.8, 12.7, 13.0, 13.4, 13.8, 14.4, 14.9, 15.3, 15.5, 16.0, 16.9, 17.1, 17.3, 17.6, 18.0, 18.3, 18.7, 19.5, 20.3, 20.8, 21.2, 21.6, 21.8, 22.1, 22.6, 23.0, 23.5, 24.1, 24.4, 24.8, 25.2, 25.5, 25.9, 27.0, 27.4, 27.9, 28.5, 28.8, 29.2, 29.6, 29.8, 30.2, 30.4, 30.8, 31.2, 31.6, 31.8, 32.2, 32.9, 33.0,  33.2, 33.5, 33.8]
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: ThirdPage(), tag: "ThirdPage", selection: $selection) { EmptyView() }
                NavigationLink(destination: FirstPage(), tag: "FirstPage", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "secondPageImage.jpg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 342)
                }
                
                label
                    .lineSpacing(2)
                    .frame(width: 350, height: 280)
                    .font(Font.system(size: 18, weight: .regular, design: .serif))
                    .padding(.bottom, 5)
                    .onReceive(timer) { time in
                        if startTime == nil {
                            startTime = time
                            playSound(sound: "secondPageAudio", type: "mp3")
                            currentWord = 0
                            currentChar = 0
                        }
                        if let start = startTime {
                            let interval = time.timeIntervalSince(start)
                            if let currentWord = currentWord, let currentChar = currentChar, interval > timeCodes[currentWord] {
                                if currentWord == words.count {
                                    self.currentWord = nil
                                    self.currentChar = nil
                                    label = Text(text)
                                } else {
                                    self.currentChar = currentChar + words[currentWord].count + 1
                                    self.currentWord = currentWord + 1
                                    
                                    let attrStr = NSMutableAttributedString(string: text)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.black.withAlphaComponent(0.8), range: NSRange(location: 0, length: text.count))
                                    let range = NSRange(location: currentChar, length: words[currentWord].count)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.systemOrange, range: range)
                                    label = Text(AttributedString(attrStr))
                                }
                            }
                        }
                    }
                
                HStack {
                    Button(action: {
                        self.selection = "FirstPage"
                    }) {
                        if let image = UIImage(named: "arrowLeft.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.leading, 10)
                    .frame(width: 58.4, height: 30)
                    
                    Spacer()
                    
                    Button(action: {
                        self.selection = "ThirdPage"
                    }) {
                        if let image = UIImage(named: "arrow-2.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.trailing, 10)
                    .frame(width: 58.4, height: 30)
                }
                .padding(.bottom, 10)
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
