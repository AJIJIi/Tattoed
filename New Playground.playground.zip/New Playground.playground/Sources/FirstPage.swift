import SwiftUI

public struct FirstPage: View {
    public init() {
        self.label = Text(text)
        self.words = text.components(separatedBy: " ")
    }
    
    @State private var selection: String?
    @State private var currentWord: Int?
    @State private var currentChar: Int?
    @State private var startTime: Date?
    @State private var label = Text("")
    private var words: [String] = []
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    private let text = "Once upon a time there was a world full of living pumpkins. The concept of beauty in this world is to be scary and creepy. The pumpkins all live together on a farm and every year the farm has a fair with a super pumpkin parade. Normally, the pumpkin that wins the award every year is the spookiest and most evil."
    private let timeCodes = [0.0, 0.3, 0.6, 0.9, 1.2, 1.5, 1.8, 2.1, 2.4, 2.7, 3.0, 3.3, 4.5, 4.7, 5.1, 5.3, 5.6, 5.9, 6.1, 6.6, 6.8, 7.0, 7.2, 7.5, 7.7, 8.9, 9.1, 9.4, 9.6, 9.9, 10.6, 10.8, 11.0, 11.7, 11.8, 12.0, 12.5, 12.8, 13.1, 13.4, 13.6, 13.8, 14.0, 14.2, 14.5, 15.1, 16.1, 16.7, 17.0, 17.4, 17.6, 18.0, 18.3, 18.6, 19.0, 19.5, 19.8, 20.1, 20.7, 21.0, 21.3, 22.0]
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: SecondPage(), tag: "SecondPage", selection: $selection) { EmptyView() }
                NavigationLink(destination: Cover(), tag: "Cover", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "firstPageImage.jpg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 436)
                }
                
                label
                    .lineSpacing(2)
                    .frame(width: 350, height: 186)
                    .font(Font.system(size: 18, weight: .regular, design: .serif))
                    .padding(.bottom, 5)
                    .onReceive(timer) { time in
                        if startTime == nil {
                            startTime = time
                            playSound(sound: "firstPageAudio", type: "m4a")
                            currentWord = 0
                            currentChar = 0
                        }
                        if let start = startTime {
                            let interval = time.timeIntervalSince(start)
                            if let currentWord = currentWord, let currentChar = currentChar, interval > timeCodes[currentWord] {
                                if currentWord == words.count {
                                    self.currentWord = nil
                                    self.currentChar = nil
                                    label = Text(text)
                                } else {
                                    self.currentChar = currentChar + words[currentWord].count + 1
                                    self.currentWord = currentWord + 1
                                    
                                    let attrStr = NSMutableAttributedString(string: text)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.black.withAlphaComponent(0.8), range: NSRange(location: 0, length: text.count))
                                    let range = NSRange(location: currentChar, length: words[currentWord].count)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.systemOrange, range: range)
                                    label = Text(AttributedString(attrStr))
                                }
                            }
                        }
                    }
                
                HStack {
                    Button(action: {
                        self.selection = "Cover"
                    }) {
                        if let image = UIImage(named: "arrowLeft.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.leading, 10)
                    .frame(width: 58.4, height: 30)
                    
                    Spacer()
                    
                    Button(action: {
                        self.selection = "SecondPage"
                    }) {
                        if let image = UIImage(named: "arrow-2.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.trailing, 10)
                    .frame(width: 58.4, height: 30)
                }
                .padding(.bottom, 10)
                
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
