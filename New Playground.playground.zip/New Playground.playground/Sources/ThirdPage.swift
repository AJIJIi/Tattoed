import SwiftUI

public struct ThirdPage: View {
    public init() {
        self.label = Text(text)
        self.words = text.components(separatedBy: " ")
    }
    
    @State private var selection: String?
    @State private var currentWord: Int?
    @State private var currentChar: Int?
    @State private var startTime: Date?
    @State private var label = Text("")
    private var words: [String] = []
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    private let text = "The day of the fair is getting closer and closer and the pumpkin is more and more sad because it can’t find anyone willing to help her or simply agree with her. To spite and scare her, the other pumpkins throw her into the river near the farm's valley. \nThe sweet pumpkin is terrified and feels more alone than ever as she rolls down the river. When her uncontrolled descent finally comes to a halt on the banks of the river, alone and cold, the sweet little pumpkin calls for help. No one comes."
    private let timeCodes = [0.0, 0.4, 0.9, 1.2, 1.5, 1.8, 2.1, 2.5, 2.9, 3.1, 3.7, 4.0, 4.3, 4.6, 4.9, 5.2, 5.4, 5.7, 6.8, 7.1, 7.3, 7.7, 8.4, 8.8, 9.2, 9.4, 9.7, 10.3, 10.7, 11.1, 11.3, 11.8, 13.0, 13.3, 13.8, 14.1, 14.4, 15.0, 15.2, 15.6, 16.0, 16.4, 16.8, 17.0, 17.4, 17.8, 18.0, 18.3, 18.7, 19.3, 19.7, 20.2, 20.6, 21.2, 21.8, 22.2, 22.6, 23.0, 23.4, 23.6, 24.0, 24.2, 24.4, 24.6, 24.8, 25.2, 25.7, 26.0, 26.3, 27.0, 27.6, 28.0, 28.4, 28.6, 28.9, 29.2, 29.4, 29.6, 29.8, 30.1, 30.4, 31.1, 31.4, 31.8, 32.2, 32.5, 32.8, 33.1, 33.3, 33.6, 34.1, 34.9, 35.0, 35.6, 36.4]
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: FourthPage(), tag: "FourthPage", selection: $selection) { EmptyView() }
                NavigationLink(destination: SecondPage(), tag: "SecondPage", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "thirdPageImage.jpg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 322)
                        .padding(.top, 10)
                }
                
                label
                    .lineSpacing(2)
                    .frame(width: 350, height: 290)
                    .font(Font.system(size: 18, weight: .regular, design: .serif))
                    .padding(.bottom, 5)
                    .onReceive(timer) { time in
                        if startTime == nil {
                            startTime = time
                            playSound(sound: "thirdPageAudio", type: "mp3")
                            currentWord = 0
                            currentChar = 0
                        }
                        if let start = startTime {
                            let interval = time.timeIntervalSince(start)
                            if let currentWord = currentWord, let currentChar = currentChar, interval > timeCodes[currentWord] {
                                if currentWord == words.count {
                                    self.currentWord = nil
                                    self.currentChar = nil
                                    label = Text(text)
                                } else {
                                    self.currentChar = currentChar + words[currentWord].count + 1
                                    self.currentWord = currentWord + 1
                                    
                                    let attrStr = NSMutableAttributedString(string: text)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.black.withAlphaComponent(0.8), range: NSRange(location: 0, length: text.count))
                                    let range = NSRange(location: currentChar, length: words[currentWord].count)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.systemOrange, range: range)
                                    label = Text(AttributedString(attrStr))
                                }
                            }
                        }
                    }
                
                HStack {
                    Button(action: {
                        self.selection = "SecondPage"
                    }) {
                        if let image = UIImage(named: "arrowLeft.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.leading, 10)
                    .frame(width: 58.4, height: 30)
                    
                    Spacer()
                    
                    Button(action: {
                        self.selection = "FourthPage"
                    }) {
                        if let image = UIImage(named: "arrow-2.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.trailing, 10)
                    .frame(width: 58.4, height: 30)
                }
                .padding(.bottom, 10)
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
