import SwiftUI

public struct SixthPage: View {
    public init() {
        self.label = Text(text)
        self.words = text.components(separatedBy: " ")
    }
    
    @State private var selection: String?
    @State private var currentWord: Int?
    @State private var currentChar: Int?
    @State private var startTime: Date?
    @State private var label = Text("")
    private var words: [String] = []
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    private let text = "The fair is here and it's parade day. People see such a beautiful pumpkin and all they can do is let her win. The other pumpkins finally realize that they don't have to be scary to be beautiful and apologize to the hero pumpkin for all the mischief. \nThe world of pumpkins changes forever. It’s no longer a world where pumpkins can only be scary and bad. Now all pumpkins want to be nice and friendly to people. From this moment on, the young boy and the pumpkin always remained friends."
    private let timeCodes = [0.0, 0.6, 1.1, 1.6, 2.1, 2.5, 3.0, 3.4, 3.8, 4.3, 4.8, 5.1, 5.4, 5.7, 6.0, 6.3, 6.6, 6.9, 7.2, 7.8, 8.2, 8.4, 8.7, 9.0, 10.3, 10.8, 11.2, 11.5, 11.8, 12.1, 12.4, 12.7, 13.0, 13.2, 13.5, 13.8, 14.1, 14.3, 14.6, 14.9, 15.2, 15.5, 15.8, 16.1, 16.3, 16.6, 16.9, 17.2, 17.5, 18.5, 19.8, 20.1, 20.4, 20.6, 21.2, 21.4, 21.7, 22.9, 23.2, 23.5, 23.8, 24.1, 24.3, 24.5, 24.8, 25.2, 25.4, 25.7, 26.0, 26.8, 27.0, 27.3, 27.6, 28.9, 29.1, 29.4, 29.7, 29.9, 30.2, 30.5, 31.5, 31.8, 32.1, 32.3, 32.6, 32.9, 33.2, 33.5, 33.9, 34.6, 35.2, 35.8, 36.3]
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: FifthPage(), tag: "FifthPage", selection: $selection) { EmptyView() }
                NavigationLink(destination: Ending(), tag: "Ending", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "sixthPageImage.jpg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 313)
                        .padding(.top, 5)
                }
                
                label
                    .lineSpacing(2)
                    .frame(width: 350, height: 304)
                    .font(Font.system(size: 18, weight: .regular, design: .serif))
                    .padding(.bottom, 5)
                    .onReceive(timer) { time in
                        if startTime == nil {
                            startTime = time
                            playSound(sound: "sixthPageAudio", type: "mp3")
                            currentWord = 0
                            currentChar = 0
                        }
                        if let start = startTime {
                            let interval = time.timeIntervalSince(start)
                            if let currentWord = currentWord, let currentChar = currentChar, interval > timeCodes[currentWord] {
                                if currentWord == words.count {
                                    self.currentWord = nil
                                    self.currentChar = nil
                                    label = Text(text)
                                } else {
                                    self.currentChar = currentChar + words[currentWord].count + 1
                                    self.currentWord = currentWord + 1
                                    
                                    let attrStr = NSMutableAttributedString(string: text)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.black.withAlphaComponent(0.8), range: NSRange(location: 0, length: text.count))
                                    let range = NSRange(location: currentChar, length: words[currentWord].count)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.systemOrange, range: range)
                                    label = Text(AttributedString(attrStr))
                                }
                            }
                        }
                    }
                
                HStack {
                    Button(action: {
                        self.selection = "FifthPage"
                    }) {
                        if let image = UIImage(named: "arrowLeft.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.leading, 10)
                    .frame(width: 58.4, height: 30)
                    
                    Spacer()
                    
                    Button(action: {
                        self.selection = "Ending"
                    }) {
                        if let image = UIImage(named: "arrow-2.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.trailing, 10)
                    .frame(width: 58.4, height: 30)
                }
                .padding(.bottom, 10)
                
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
