import SwiftUI

public struct FifthPage: View {
    public init() {
        self.label = Text(text)
        self.words = text.components(separatedBy: " ")
    }
    
    @State private var selection: String?
    @State private var currentWord: Int?
    @State private var currentChar: Int?
    @State private var startTime: Date?
    @State private var label = Text("")
    private var words: [String] = []
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    private let text = "The tiny pumpkin bursts into tears and begins to tell her misadventure. She explains that she feels pretty and wants to be good, not scary. One of her dreams is to become the cutest pumpkin on the farm and win the parade. \nSo the child decides to go back to the farm with her. They soon become friends. The child likes the pumpkin's point of view and decides to help her. \nThe night before the fair, the child wants to help his friend and decides to transform the adorable pumpkin; he makes it beautiful, smiling, and even puts lipstick on. The pumpkin feels as great as ever, she’s just as she wished to be."
    private let timeCodes = [0, 1.4, 1.6, 1.8, 2.4, 2.6, 2.8, 3.4, 3.6, 4.6, 5.4, 5.8, 7, 7.2, 7.6, 7.8, 8.4, 8.9, 9.2, 9.6, 10, 10.4, 10.6, 10.9, 11.4, 11.8, 12.4, 12.6, 12.9, 13.2, 13.4, 13.6, 13.9, 14.2, 14.6, 14.9, 15.4, 15.7, 16, 16.4, 16.7, 17.6, 18, 18.6, 18.9, 20.2, 20.4, 20.6, 20.8, 21, 21.2, 21.4, 21.6, 21.8, 22.6, 23, 23.4, 23.9, 24.6, 25.2, 25.6, 25.8, 26, 26.6, 27, 27.4, 27.6, 27.8, 28.4, 28.6, 28.8, 30.0, 30.3, 30.6, 30.9, 31.2, 31.5, 31.8, 32.1, 32.4, 32.7, 33.0, 33.3, 33.6, 33.9, 34.2, 34.5, 34.8, 35.1, 35.4, 36.5, 37.0, 37.3, 37.5, 37.9, 38.5, 39.0, 39.4, 39.9, 40.5, 41.0, 41.5, 41.8, 42.0, 42.5, 42.9, 43.4, 43.9, 44.4, 44.8, 45.3, 45.7, 46.3, 46.7, 47.2]
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: SixthPage(), tag: "SixthPage", selection: $selection) { EmptyView() }
                NavigationLink(destination: FourthPage(), tag: "FourthPage", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "fifthPageImage.jpg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 228)
                        .padding(.top, 10)
                        .padding(.bottom, 10)
                }
                
                label
                    .lineSpacing(2)
                    .frame(width: 350, height: 374)
                    .font(Font.system(size: 18, weight: .regular, design: .serif))
                    .padding(.bottom, 5)
                    .onReceive(timer) { time in
                        if startTime == nil {
                            startTime = time
                            playSound(sound: "fifthPageAudio", type: "mp3")
                            currentWord = 0
                            currentChar = 0
                        }
                        if let start = startTime {
                            let interval = time.timeIntervalSince(start)
                            if let currentWord = currentWord, let currentChar = currentChar, interval > timeCodes[currentWord] {
                                if currentWord == words.count {
                                    self.currentWord = nil
                                    self.currentChar = nil
                                    label = Text(text)
                                } else {
                                    self.currentChar = currentChar + words[currentWord].count + 1
                                    self.currentWord = currentWord + 1
                                    
                                    let attrStr = NSMutableAttributedString(string: text)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.black.withAlphaComponent(0.8), range: NSRange(location: 0, length: text.count))
                                    let range = NSRange(location: currentChar, length: words[currentWord].count)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.systemOrange, range: range)
                                    label = Text(AttributedString(attrStr))
                                }
                            }
                        }
                    }
                
                HStack {
                    Button(action: {
                        self.selection = "FourthPage"
                    }) {
                        if let image = UIImage(named: "arrowLeft.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.leading, 10)
                    .frame(width: 58.4, height: 30)
                    
                    Spacer()
                    
                    Button(action: {
                        self.selection = "SixthPage"
                    }) {
                        if let image = UIImage(named: "arrow-2.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.trailing, 10)
                    .frame(width: 58.4, height: 30)
                }
                .padding(.bottom, 10)
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}

