import SwiftUI

public struct Cover: View {
    public init() {}
    
    @State private var selection: String?
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: FirstPage(), tag: "FirstPage", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "cover.jpg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 622)
                        .padding(.bottom, 5)
                }
                
                HStack {
                    Spacer()
                    
                    Button(action: {
                        self.selection = "FirstPage"
                    }) {
                        if let image = UIImage(named: "arrow-2.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.trailing, 10)
                    .frame(width: 58.4, height: 30)
                }
                .padding(.bottom, 10)
                
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
