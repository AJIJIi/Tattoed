import SwiftUI

public struct FourthPage: View {
    public init() {
        self.label = Text(text)
        self.words = text.components(separatedBy: " ")
    }
    
    @State private var selection: String?
    @State private var currentWord: Int?
    @State private var currentChar: Int?
    @State private var startTime: Date?
    @State private var label = Text("")
    private var words: [String] = []
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    private let text = "The lovely pumpkin is very tired and is dragging herself all soaked on the path leading to the farm, by now she’s almost on the threshold of giving up. Suddenly, as if by magic, she meets a child on the path. \nThe child picks up the little pumpkin and takes it in his arms exclaiming: What are you doing here? Why are you sad, little pumpkin?"
    private let timeCodes = [0.0, 0.3, 0.6, 1.1, 1.3, 2, 2.3, 2.7, 3.1, 3.6, 4.4, 4.7, 5.0, 5.3, 5.6, 6.0, 6.5, 6.6, 6.9, 7.4, 7.9, 8.2, 8.7, 8.9, 9.1, 9.8, 10.0, 10.6, 11.0, 11.5, 12.6, 13.2, 13.5, 13.8, 14.3, 15.2, 15.4, 15.6, 15.8, 16, 16.2, 16.8, 17.6, 17.9, 18.3, 18.6, 18.8, 19, 19.4, 19.8, 20.4, 20.6, 21.4, 21.6, 22.2, 23, 23.6, 23.9, 24.2, 24.6, 25.0, 25.2, 25.5, 25.8, 26.1, 26.6, 27.1]
    
    public var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                NavigationLink(destination: FifthPage(), tag: "FifthPage", selection: $selection) { EmptyView() }
                NavigationLink(destination: ThirdPage(), tag: "ThirdPage", selection: $selection) { EmptyView() }
                
                if let image = UIImage(named: "fourthPageImage.jpg") {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 350, height: 402)
                        .padding(.bottom, 10)
                }
                
                label
                    .lineSpacing(2)
                    .frame(width: 350, height: 210)
                    .font(Font.system(size: 18, weight: .regular, design: .serif))
                    .padding(.bottom, 5)
                    .onReceive(timer) { time in
                        if startTime == nil {
                            startTime = time
                            playSound(sound: "fourthPageAudio", type: "mp3")
                            currentWord = 0
                            currentChar = 0
                        }
                        if let start = startTime {
                            let interval = time.timeIntervalSince(start)
                            if let currentWord = currentWord, let currentChar = currentChar, interval > timeCodes[currentWord] {
                                if currentWord == words.count {
                                    self.currentWord = nil
                                    self.currentChar = nil
                                    label = Text(text)
                                } else {
                                    self.currentChar = currentChar + words[currentWord].count + 1
                                    self.currentWord = currentWord + 1
                                    
                                    let attrStr = NSMutableAttributedString(string: text)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.black.withAlphaComponent(0.8), range: NSRange(location: 0, length: text.count))
                                    let range = NSRange(location: currentChar, length: words[currentWord].count)
                                    attrStr.addAttribute(.foregroundColor, value: UIColor.systemOrange, range: range)
                                    label = Text(AttributedString(attrStr))
                                }
                            }
                        }
                    }
                
                HStack {
                    Button(action: {
                        self.selection = "ThirdPage"
                    }) {
                        if let image = UIImage(named: "arrowLeft.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.leading, 10)
                    .frame(width: 58.4, height: 30)
                    
                    Spacer()
                    
                    Button(action: {
                        self.selection = "FifthPage"
                    }) {
                        if let image = UIImage(named: "arrow-2.jpg") {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                        }
                    }
                    .padding(.trailing, 10)
                    .frame(width: 58.4, height: 30)
                }
                .padding(.bottom, 10)
            }
            .frame(width: 375, height: 667)
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
